script.clarkeyepg
===============

Clarkey EPG allows you to combine some of your favourite live TV plugins for use with a fully working EPG.

Based on the original TV Guide by twinther.

**PLEASE NOTE:** 
This repository is used for development purposes only and may contain untested, experimental and unstable code. 
